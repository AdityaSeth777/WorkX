import React from 'react';

function Home() {
    return (
        <main>
            <h2>Welcome to the Freelance Marketplace</h2>
            <p>Find the best freelance jobs and hire top talent for your projects.</p>
        </main>
    );
}

export default Home;
