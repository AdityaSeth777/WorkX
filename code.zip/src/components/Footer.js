import React from 'react';

function Footer() {
    return (
        <footer>
            <p>© 2024 Freelance Marketplace. All rights reserved.</p>
        </footer>
    );
}

export default Footer;
